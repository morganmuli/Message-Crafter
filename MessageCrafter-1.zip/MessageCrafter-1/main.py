import os
import json
import logging
import time
import datetime
from flask import Flask, render_template, request, jsonify, g
from flask_cors import CORS
from flask_login import current_user, login_required
from openai import OpenAI, APIError
from models import db, MessageGeneration, User, FavoriteMessage, MessageFeedback, AnalyticsData
from auth import init_app as init_auth
from payments import init_app as init_payments

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
app.secret_key = os.environ.get("SESSION_SECRET", "openr-ai-secret-key")

# Configure database
database_url = os.environ.get("DATABASE_URL")
if database_url:
    app.config["SQLALCHEMY_DATABASE_URI"] = database_url
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    logger.info("Database URL found and configured")
else:
    logger.error("DATABASE_URL environment variable not found!")

# Initialize database
db.init_app(app)

# Initialize authentication
init_auth(app)

# Initialize payments
init_payments(app)

# Create tables
with app.app_context():
    db.create_all()

# Get OpenAI API key from environment variable
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    logger.warning("OpenAI API key not found in environment variables!")

# Initialize OpenAI client
openai = OpenAI(api_key=OPENAI_API_KEY)

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index_new.html')

@app.route('/login')
def login_route():
    """Direct route to login page"""
    return redirect(url_for('auth.login'))

@app.route('/signup')
def signup_route():
    """Direct route to signup page"""
    return redirect(url_for('auth.register'))

@app.route('/history-page')
def history_page():
    """Render the history page"""
    return render_template('history.html')

@app.route('/favorites-page')
@login_required
def favorites_page():
    """Render the favorites page"""
    return render_template('favorites.html')

@app.route('/upgrade')
def upgrade_page():
    """Render the upgrade/pricing page"""
    return render_template('upgrade.html')

@app.route('/pricing')
def pricing_route():
    """Direct route to pricing/upgrade page"""
    return redirect(url_for('upgrade_page'))

@app.route('/history', methods=['GET'])
def get_message_history():
    """Get message generation history from the database"""
    try:
        # Query the database for message history (most recent first)
        history = MessageGeneration.query.order_by(MessageGeneration.created_at.desc()).limit(50).all()
        
        # Convert to list of dictionaries
        history_list = [item.to_dict() for item in history]
        
        return jsonify({"history": history_list})
    except Exception as e:
        logger.error(f"Error retrieving history: {str(e)}")
        return jsonify({"error": f"Could not retrieve message history: {str(e)}"}), 500

@app.route('/generate', methods=['POST'])
def generate_messages():
    """
    Generate message suggestions using OpenAI API
    
    Accepts JSON payload with:
    - situation: context of the message
    - tone: desired tone (Friendly, Professional, Casual, Bold)
    - platform: platform for the message (LinkedIn, Email, Instagram, Twitter, WhatsApp)
    - recipient: (optional) details about the recipient
    - language: (optional) language for the message (default: 'en')
    
    Returns JSON with an array of message suggestions
    """
    try:
        # Start timing the request
        start_time = time.time()
        
        # Validate request
        if not request.is_json:
            return jsonify({"error": "Request must be JSON"}), 400
        
        data = request.get_json()
        logger.debug(f"Received data: {data}")
        
        # Check required fields
        required_fields = ['situation', 'tone', 'platform']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        
        # Extract fields
        situation = data.get('situation')
        tone = data.get('tone')
        platform = data.get('platform')
        recipient = data.get('recipient', '')
        language = data.get('language', 'en')
        
        # Get active user ID if logged in
        user_id = current_user.id if current_user.is_authenticated else None
        
        # Check if user has reached their generation limit
        if user_id:
            # Pro users don't have a limit
            if not current_user.is_pro():
                today_count = MessageGeneration.query.filter(
                    MessageGeneration.user_id == user_id,
                    MessageGeneration.created_at >= datetime.datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
                ).count()
                
                if today_count >= 5:  # Free tier limit
                    return jsonify({
                        "error": "You've reached your daily message generation limit. Upgrade to Pro for unlimited generations.",
                        "limit_reached": True
                    }), 429
        
        # Determine which API key to use
        api_key = OPENAI_API_KEY
        if user_id and current_user.is_pro() and current_user.custom_api_key:
            # Pro users can use their own API key
            api_key = current_user.custom_api_key
            logger.debug("Using custom API key from user")
        
        if not api_key:
            return jsonify({"error": "OpenAI API key not configured"}), 500
        
        # Create language-specific prompts
        lang_instructions = ""
        if language != 'en':
            lang_instructions = f" Write the messages in {language} language."
        
        # Create prompt for OpenAI
        prompt = f"""You are a professional message composer. Write 3 variations of a first message or DM based on:

Situation: {situation}

Tone: {tone}

Platform: {platform}

Recipient info: {recipient}

Make each message unique, human, and suitable for the platform. Keep them under 300 characters for Twitter or Instagram, or under 500 for email or LinkedIn.{lang_instructions}"""
        
        # Setup a custom OpenAI client instance if using a custom key
        if user_id and current_user.is_pro() and current_user.custom_api_key:
            custom_openai = OpenAI(api_key=api_key)
            openai_client = custom_openai
        else:
            openai_client = openai
        
        # Call OpenAI API
        logger.debug("Calling OpenAI API")
        response = openai_client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[
                {"role": "system", "content": "You are a helpful assistant that generates message openers."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.7,
        )
        
        # Calculate processing time
        processing_time_ms = int((time.time() - start_time) * 1000)
        
        # Extract content from response
        result = response.choices[0].message.content
        logger.debug(f"OpenAI response: {result}")
        
        # Parse messages from the response
        messages = extract_messages(result)
        
        # Save to database
        try:
            message_history = MessageGeneration(
                user_id=user_id,
                situation=situation,
                tone=tone,
                platform=platform,
                recipient_info=recipient,
                language=language,
                generation_time_ms=processing_time_ms
            )
            
            # Store individual messages
            if len(messages) > 0:
                message_history.message_1 = messages[0]
            if len(messages) > 1:
                message_history.message_2 = messages[1]
            if len(messages) > 2:
                message_history.message_3 = messages[2]
                
            db.session.add(message_history)
            db.session.commit()
            logger.debug(f"Saved message generation with ID: {message_history.id}")
            
            # Track analytics
            analytics_data = AnalyticsData(
                event_type='message_generation',
                user_id=user_id,
                message_generation_id=message_history.id,
                platform=platform,
                tone=tone,
                language=language,
                additional_data={"processing_time_ms": processing_time_ms}
            )
            db.session.add(analytics_data)
            db.session.commit()
            
            # Return the generated ID along with the messages
            return jsonify({
                "messages": messages,
                "generation_id": message_history.id,
                "processing_time_ms": processing_time_ms
            })
            
        except Exception as e:
            logger.error(f"Failed to save to database: {str(e)}")
            db.session.rollback()
            # Continue even if database save fails
            return jsonify({"messages": messages})
    
    except APIError as e:
        logger.error(f"OpenAI API error: {str(e)}")
        error_message = str(e)
        
        # Check for quota exceeded error
        if "insufficient_quota" in error_message or "exceeded your current quota" in error_message:
            return jsonify({
                "error": "API quota exceeded. The OpenAI API key has reached its usage limit. Please try again later or contact support for assistance.",
                "messages": [
                    "This is a sample message for LinkedIn. It would normally be generated by AI but is currently unavailable due to API quota limitations.",
                    "Here's another example of what a message might look like. The AI service is temporarily unavailable.",
                    "This is the third message placeholder. Please try again later when the API quota has been reset."
                ]
            }), 429
        
        return jsonify({"error": f"OpenAI API error: {str(e)}"}), 500
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@app.route('/favorites', methods=['GET'])
@login_required
def get_favorite_messages():
    """Get user's favorite messages"""
    try:
        # Get user's favorite messages with the generation info
        favorites = FavoriteMessage.query.filter_by(user_id=current_user.id).order_by(FavoriteMessage.created_at.desc()).all()
        
        # Prepare response data with message content
        favorite_messages = []
        for fav in favorites:
            # Get the message based on the index
            message_content = None
            if fav.message_index == 0 and fav.message_generation.message_1:
                message_content = fav.message_generation.message_1
            elif fav.message_index == 1 and fav.message_generation.message_2:
                message_content = fav.message_generation.message_2
            elif fav.message_index == 2 and fav.message_generation.message_3:
                message_content = fav.message_generation.message_3
                
            if message_content:
                favorite_messages.append({
                    'id': fav.id,
                    'message_generation_id': fav.message_generation_id,
                    'message_index': fav.message_index,
                    'content': message_content,
                    'platform': fav.message_generation.platform,
                    'tone': fav.message_generation.tone,
                    'situation': fav.message_generation.situation,
                    'created_at': fav.created_at.isoformat() if fav.created_at else None
                })
        
        return jsonify({"favorites": favorite_messages})
    except Exception as e:
        logger.error(f"Error retrieving favorites: {str(e)}")
        return jsonify({"error": f"Could not retrieve favorite messages: {str(e)}"}), 500

@app.route('/favorites', methods=['POST'])
@login_required
def add_favorite_message():
    """Add a message to user's favorites"""
    try:
        if not request.is_json:
            return jsonify({"error": "Request must be JSON"}), 400
            
        data = request.get_json()
        
        # Check required fields
        required_fields = ['generation_id', 'message_index']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        
        generation_id = data['generation_id']
        message_index = data['message_index']
        
        # Make sure the message generation exists
        message_gen = MessageGeneration.query.get(generation_id)
        if not message_gen:
            return jsonify({"error": "Message generation not found"}), 404
            
        # Check if message_index is valid (0, 1, or 2)
        if message_index not in [0, 1, 2]:
            return jsonify({"error": "Invalid message index"}), 400
            
        # Make sure the message at that index exists
        message_content = None
        if message_index == 0:
            message_content = message_gen.message_1
        elif message_index == 1:
            message_content = message_gen.message_2
        elif message_index == 2:
            message_content = message_gen.message_3
            
        if not message_content:
            return jsonify({"error": "No message content at specified index"}), 400
            
        # Check if already favorited
        existing_favorite = FavoriteMessage.query.filter_by(
            user_id=current_user.id,
            message_generation_id=generation_id,
            message_index=message_index
        ).first()
        
        if existing_favorite:
            return jsonify({"message": "Message already in favorites", "favorite_id": existing_favorite.id}), 200
            
        # Add to favorites
        favorite = FavoriteMessage(
            user_id=current_user.id,
            message_generation_id=generation_id,
            message_index=message_index
        )
        
        db.session.add(favorite)
        db.session.commit()
        
        # Track analytics
        analytics_data = AnalyticsData(
            event_type='message_favorited',
            user_id=current_user.id,
            message_generation_id=generation_id,
            platform=message_gen.platform,
            tone=message_gen.tone
        )
        db.session.add(analytics_data)
        db.session.commit()
        
        return jsonify({
            "message": "Message added to favorites",
            "favorite_id": favorite.id
        }), 201
    except Exception as e:
        logger.error(f"Error adding favorite: {str(e)}")
        db.session.rollback()
        return jsonify({"error": f"Could not add message to favorites: {str(e)}"}), 500

@app.route('/favorites/<int:favorite_id>', methods=['DELETE'])
@login_required
def remove_favorite_message(favorite_id):
    """Remove a message from user's favorites"""
    try:
        favorite = FavoriteMessage.query.get(favorite_id)
        
        if not favorite:
            return jsonify({"error": "Favorite not found"}), 404
            
        # Make sure it belongs to the current user
        if favorite.user_id != current_user.id:
            return jsonify({"error": "Unauthorized"}), 403
            
        generation_id = favorite.message_generation_id
        
        # Delete the favorite
        db.session.delete(favorite)
        db.session.commit()
        
        # Track analytics
        analytics_data = AnalyticsData(
            event_type='message_unfavorited',
            user_id=current_user.id,
            message_generation_id=generation_id
        )
        db.session.add(analytics_data)
        db.session.commit()
        
        return jsonify({"message": "Favorite removed successfully"})
    except Exception as e:
        logger.error(f"Error removing favorite: {str(e)}")
        db.session.rollback()
        return jsonify({"error": f"Could not remove favorite: {str(e)}"}), 500

@app.route('/message-action', methods=['POST'])
def track_message_action():
    """Track message actions (copy, share)"""
    try:
        if not request.is_json:
            return jsonify({"error": "Request must be JSON"}), 400
            
        data = request.get_json()
        
        # Check required fields
        required_fields = ['action_type', 'generation_id', 'message_index']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        
        action_type = data['action_type']
        generation_id = data['generation_id']
        message_index = data['message_index']
        
        # Validate action_type
        valid_actions = ['copy', 'share']
        if action_type not in valid_actions:
            return jsonify({"error": f"Invalid action type. Must be one of: {', '.join(valid_actions)}"}), 400
            
        # Get message generation
        message_gen = MessageGeneration.query.get(generation_id)
        if not message_gen:
            return jsonify({"error": "Message generation not found"}), 404
            
        # Track the action in analytics
        user_id = current_user.id if current_user.is_authenticated else None
        
        analytics_data = AnalyticsData(
            event_type=f'message_{action_type}',
            user_id=user_id,
            message_generation_id=generation_id,
            platform=message_gen.platform,
            tone=message_gen.tone,
            additional_data={"message_index": message_index}
        )
        db.session.add(analytics_data)
        db.session.commit()
        
        return jsonify({"message": f"Message {action_type} action tracked successfully"})
    except Exception as e:
        logger.error(f"Error tracking message action: {str(e)}")
        db.session.rollback()
        return jsonify({"error": f"Could not track message action: {str(e)}"}), 500

def extract_messages(text):
    """
    Extract separate messages from OpenAI's response
    
    This function tries to parse the generated text into separate messages.
    It handles various formats that the model might return.
    """
    # First try to detect if the response has numbered messages like "1.", "2.", etc.
    lines = text.split('\n')
    messages = []
    current_message = ""
    message_started = False
    
    for line in lines:
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
            
        # Check if line starts a new message (patterns like "1.", "Message 1:", etc.)
        if (line.startswith(('1.', '2.', '3.')) or 
            line.lower().startswith(('message 1', 'option 1', 'variation 1'))):
            
            # If we already have a message in progress, save it
            if message_started and current_message:
                messages.append(current_message.strip())
                current_message = ""
            
            # Start new message, removing the number/prefix
            parts = line.split(':', 1)
            if len(parts) > 1:
                current_message = parts[1].strip()
            else:
                # Remove the numbering (e.g., "1. ")
                if '.' in line[:3]:
                    current_message = line.split('.', 1)[1].strip()
                else:
                    current_message = line
            
            message_started = True
            
        # If we're in a message, add this line to it
        elif message_started:
            current_message += " " + line
    
    # Add the last message if there is one
    if message_started and current_message:
        messages.append(current_message.strip())
    
    # If we couldn't identify separate messages, treat the whole response as one message
    # or split by double newlines as a fallback
    if not messages:
        if '\n\n' in text:
            messages = [msg.strip() for msg in text.split('\n\n') if msg.strip()]
        else:
            messages = [text.strip()]
    
    # Ensure we have exactly 3 messages (or fewer if that's all we could extract)
    return messages[:3]

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
