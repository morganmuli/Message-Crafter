from flask import Blueprint, current_app, request, redirect, url_for, jsonify, session, flash, render_template
from flask_login import current_user, login_required
import os
import logging
import requests
import json
import uuid
from datetime import datetime

from models import db, User, UserSubscription

# Configure logging
logger = logging.getLogger(__name__)

# Create blueprint for payment routes
payments_bp = Blueprint('payments', __name__, url_prefix='/payments')

# PayPal settings (production vs sandbox)
PAYPAL_MODE = os.environ.get('PAYPAL_MODE', 'sandbox')  # 'sandbox' or 'live'
PAYPAL_CLIENT_ID = os.environ.get('PAYPAL_CLIENT_ID', '')
PAYPAL_CLIENT_SECRET = os.environ.get('PAYPAL_CLIENT_SECRET', '')

# PayPal API URLs
if PAYPAL_MODE == 'live':
    PAYPAL_API_URL = 'https://api.paypal.com'
else:
    PAYPAL_API_URL = 'https://api-m.sandbox.paypal.com'

# Define plan details
PLANS = {
    'monthly': {
        'name': 'MessageCrafter Pro Monthly',
        'description': 'Monthly subscription to MessageCrafter Pro',
        'price': 9.99,
        'currency': 'USD',
        'frequency': {
            'interval_unit': 'MONTH',
            'interval_count': 1
        }
    },
    'annual': {
        'name': 'MessageCrafter Pro Annual',
        'description': 'Annual subscription to MessageCrafter Pro (20% off)',
        'price': 99.99,
        'currency': 'USD',
        'frequency': {
            'interval_unit': 'YEAR',
            'interval_count': 1
        }
    }
}

# PayPal API functions
def get_paypal_access_token():
    """Get PayPal OAuth access token"""
    try:
        auth = (PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET)
        response = requests.post(
            f"{PAYPAL_API_URL}/v1/oauth2/token",
            auth=auth,
            headers={"Accept": "application/json", "Accept-Language": "en_US"},
            data={"grant_type": "client_credentials"}
        )
        
        response.raise_for_status()
        data = response.json()
        return data["access_token"]
    except requests.exceptions.RequestException as e:
        logger.error(f"Error getting PayPal access token: {str(e)}")
        return None

def create_paypal_product(name, description):
    """Create a PayPal product"""
    try:
        access_token = get_paypal_access_token()
        if not access_token:
            return None
            
        response = requests.post(
            f"{PAYPAL_API_URL}/v1/catalogs/products",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            },
            json={
                "name": name,
                "description": description,
                "type": "SERVICE",
                "category": "SOFTWARE"
            }
        )
        
        response.raise_for_status()
        return response.json()["id"]
    except requests.exceptions.RequestException as e:
        logger.error(f"Error creating PayPal product: {str(e)}")
        return None

def create_paypal_plan(product_id, plan_name, plan_description, currency, value, interval_unit, interval_count):
    """Create a PayPal subscription plan"""
    try:
        access_token = get_paypal_access_token()
        if not access_token:
            return None
            
        response = requests.post(
            f"{PAYPAL_API_URL}/v1/billing/plans",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            },
            json={
                "product_id": product_id,
                "name": plan_name,
                "description": plan_description,
                "status": "ACTIVE",
                "billing_cycles": [
                    {
                        "frequency": {
                            "interval_unit": interval_unit,
                            "interval_count": interval_count
                        },
                        "tenure_type": "REGULAR",
                        "sequence": 1,
                        "total_cycles": 0,
                        "pricing_scheme": {
                            "fixed_price": {
                                "value": str(value),
                                "currency_code": currency
                            }
                        }
                    }
                ],
                "payment_preferences": {
                    "auto_bill_outstanding": True,
                    "setup_fee": {
                        "value": "0",
                        "currency_code": currency
                    },
                    "setup_fee_failure_action": "CONTINUE",
                    "payment_failure_threshold": 3
                }
            }
        )
        
        response.raise_for_status()
        return response.json()["id"]
    except requests.exceptions.RequestException as e:
        logger.error(f"Error creating PayPal plan: {str(e)}")
        return None

def create_paypal_subscription(plan_id, user_id, success_url, cancel_url):
    """Create a PayPal subscription"""
    try:
        access_token = get_paypal_access_token()
        if not access_token:
            return None
            
        # Generate a unique subscription reference
        subscription_reference = f"MSG-{user_id}-{uuid.uuid4().hex[:8]}"
        
        response = requests.post(
            f"{PAYPAL_API_URL}/v1/billing/subscriptions",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            },
            json={
                "plan_id": plan_id,
                "application_context": {
                    "brand_name": "MessageCrafter",
                    "locale": "en-US",
                    "shipping_preference": "NO_SHIPPING",
                    "user_action": "SUBSCRIBE_NOW",
                    "payment_method": {
                        "payer_selected": "PAYPAL",
                        "payee_preferred": "IMMEDIATE_PAYMENT_REQUIRED"
                    },
                    "return_url": success_url,
                    "cancel_url": cancel_url
                },
                "custom_id": subscription_reference,
                "subscriber": {
                    "name": {
                        "given_name": current_user.username,
                        "surname": ""
                    },
                    "email_address": current_user.email
                }
            }
        )
        
        response.raise_for_status()
        data = response.json()
        
        # Store subscription reference for verification later
        session['paypal_subscription_reference'] = subscription_reference
        
        # Find the approval URL
        for link in data["links"]:
            if link["rel"] == "approve":
                return link["href"]
                
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Error creating PayPal subscription: {str(e)}")
        return None

@payments_bp.route('/checkout')
@login_required
def checkout():
    """Display the payment options page"""
    plan_type = request.args.get('plan', 'monthly')
    
    if plan_type not in PLANS:
        flash('Invalid plan selected', 'danger')
        return redirect(url_for('upgrade_page'))
    
    return render_template('payments/checkout.html', plan=PLANS[plan_type], plan_type=plan_type)

@payments_bp.route('/process', methods=['POST'])
@login_required
def process_payment():
    """Process payment based on selected method"""
    plan_type = request.form.get('plan_type', 'monthly')
    payment_method = request.form.get('payment_method', 'paypal')
    
    if plan_type not in PLANS:
        flash('Invalid plan selected', 'danger')
        return redirect(url_for('upgrade_page'))
    
    # Store plan info in session for later use
    session['selected_plan'] = plan_type
    
    try:
        # Get domain for success/cancel URLs
        domain_url = get_domain_url()
        success_url = f"{domain_url}/payments/success"
        cancel_url = f"{domain_url}/payments/cancel"
        
        if payment_method == 'paypal':
            # Create PayPal subscription
            plan = PLANS[plan_type]
            
            # First ensure we have a product
            product_id = session.get('paypal_product_id')
            if not product_id:
                product_id = create_paypal_product(
                    "MessageCrafter Pro", 
                    "AI-powered message generation service"
                )
                if not product_id:
                    raise Exception("Failed to create PayPal product")
                session['paypal_product_id'] = product_id
            
            # Then ensure we have a plan
            plan_id_key = f'paypal_plan_id_{plan_type}'
            plan_id = session.get(plan_id_key)
            if not plan_id:
                plan_id = create_paypal_plan(
                    product_id,
                    plan['name'],
                    plan['description'],
                    plan['currency'],
                    plan['price'],
                    plan['frequency']['interval_unit'],
                    plan['frequency']['interval_count']
                )
                if not plan_id:
                    raise Exception("Failed to create PayPal plan")
                session[plan_id_key] = plan_id
            
            # Create subscription and get approval URL
            approval_url = create_paypal_subscription(
                plan_id, 
                current_user.id,
                success_url,
                cancel_url
            )
            
            if not approval_url:
                raise Exception("Failed to create PayPal subscription")
            
            # Redirect to PayPal for approval
            return redirect(approval_url)
        
        elif payment_method == 'bank_transfer':
            # Store bank transfer request in session
            session['bank_transfer_request'] = {
                'plan_type': plan_type,
                'amount': PLANS[plan_type]['price'],
                'currency': PLANS[plan_type]['currency'],
                'timestamp': datetime.utcnow().isoformat()
            }
            
            # Redirect to bank transfer instructions page
            return redirect(url_for('payments.bank_transfer_instructions'))
        
        else:
            flash('Invalid payment method selected', 'danger')
            return redirect(url_for('payments.checkout', plan=plan_type))
            
    except Exception as e:
        logger.error(f"Error processing payment: {str(e)}")
        flash('An error occurred while processing your payment. Please try again.', 'danger')
        return redirect(url_for('upgrade_page'))

@payments_bp.route('/success')
@login_required
def payment_success():
    """Handle successful PayPal payment"""
    subscription_id = request.args.get('subscription_id')
    paypal_subscription_reference = session.get('paypal_subscription_reference')
    bank_transfer_request = session.get('bank_transfer_request')
    
    if not subscription_id and not bank_transfer_request:
        flash('Invalid payment session', 'danger')
        return redirect(url_for('index'))
    
    try:
        # For PayPal subscription
        if subscription_id:
            # Verify the subscription with PayPal
            access_token = get_paypal_access_token()
            if not access_token:
                raise Exception("Failed to get PayPal access token")
                
            # Get subscription details from PayPal
            response = requests.get(
                f"{PAYPAL_API_URL}/v1/billing/subscriptions/{subscription_id}",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {access_token}"
                }
            )
            
            response.raise_for_status()
            subscription_data = response.json()
            
            # Update user to pro
            current_user.role = 'pro'
            
            # Save subscription info
            user_subscription = UserSubscription.query.filter_by(user_id=current_user.id).first()
            
            plan_type = session.get('selected_plan', 'monthly')
            
            if user_subscription:
                # Update existing subscription
                user_subscription.stripe_customer_id = None  # Clear old Stripe info if any
                user_subscription.stripe_subscription_id = None
                user_subscription.paypal_subscription_id = subscription_id
                user_subscription.plan_type = plan_type
                user_subscription.is_active = True
                user_subscription.start_date = datetime.utcnow()
                user_subscription.end_date = None
            else:
                # Create new subscription record
                user_subscription = UserSubscription(
                    user_id=current_user.id,
                    paypal_subscription_id=subscription_id,
                    plan_type=plan_type,
                    is_active=True
                )
                db.session.add(user_subscription)
            
            db.session.commit()
            
            # Clear PayPal session data
            session.pop('paypal_subscription_reference', None)
            session.pop('selected_plan', None)
            
            flash('Thank you for subscribing to MessageCrafter Pro!', 'success')
            
        # For bank transfer
        elif bank_transfer_request:
            # For bank transfers, we'll mark the user as pro but set a pending flag
            current_user.role = 'pro'
            
            # Create a new subscription record for the bank transfer
            user_subscription = UserSubscription.query.filter_by(user_id=current_user.id).first()
            
            if user_subscription:
                # Update existing subscription
                user_subscription.stripe_customer_id = None
                user_subscription.stripe_subscription_id = None
                user_subscription.paypal_subscription_id = None
                user_subscription.bank_transfer_reference = f"BANK-{current_user.id}-{uuid.uuid4().hex[:8]}"
                user_subscription.plan_type = bank_transfer_request['plan_type']
                user_subscription.is_active = True
                user_subscription.is_pending_verification = True
                user_subscription.start_date = datetime.utcnow()
                user_subscription.end_date = None
            else:
                # Create new subscription record
                user_subscription = UserSubscription(
                    user_id=current_user.id,
                    bank_transfer_reference=f"BANK-{current_user.id}-{uuid.uuid4().hex[:8]}",
                    plan_type=bank_transfer_request['plan_type'],
                    is_active=True,
                    is_pending_verification=True
                )
                db.session.add(user_subscription)
            
            db.session.commit()
            
            # Clear bank transfer session data
            session.pop('bank_transfer_request', None)
            
            flash('Thank you for your payment request! Your account will be upgraded to Pro once we verify your bank transfer.', 'success')
        
        return redirect(url_for('upgrade_page'))
        
    except Exception as e:
        logger.error(f"Error processing successful payment: {str(e)}")
        flash('An error occurred while processing your subscription. Please contact support.', 'danger')
        return redirect(url_for('index'))

@payments_bp.route('/cancel')
@login_required
def payment_cancel():
    """Handle canceled payment"""
    # Clear payment-related session data
    session.pop('paypal_subscription_reference', None)
    session.pop('selected_plan', None)
    session.pop('bank_transfer_request', None)
    
    flash('Your payment was canceled. Feel free to try again when you\'re ready.', 'info')
    return redirect(url_for('upgrade_page'))

@payments_bp.route('/bank-transfer')
@login_required
def bank_transfer_instructions():
    """Display bank transfer instructions"""
    bank_transfer_request = session.get('bank_transfer_request')
    
    if not bank_transfer_request:
        flash('Invalid bank transfer request', 'danger')
        return redirect(url_for('upgrade_page'))
    
    # Generate a unique reference code for this transfer
    reference_code = f"MC-{current_user.id}-{uuid.uuid4().hex[:6]}".upper()
    session['bank_transfer_reference'] = reference_code
    
    return render_template(
        'payments/bank_transfer.html',
        amount=bank_transfer_request['amount'],
        currency=bank_transfer_request['currency'],
        plan_type=bank_transfer_request['plan_type'],
        reference_code=reference_code
    )

@payments_bp.route('/bank-transfer/confirm', methods=['POST'])
@login_required
def confirm_bank_transfer():
    """Mark bank transfer as completed by user"""
    transaction_date = request.form.get('transaction_date')
    transaction_ref = request.form.get('transaction_ref')
    
    if not transaction_date or not transaction_ref:
        flash('Please provide both transaction date and reference number', 'danger')
        return redirect(url_for('payments.bank_transfer_instructions'))
    
    try:
        # Store the transaction details
        bank_transfer_request = session.get('bank_transfer_request', {})
        reference_code = session.get('bank_transfer_reference', '')
        
        # Create transaction record in session
        session['bank_transfer_completed'] = {
            'amount': bank_transfer_request.get('amount'),
            'currency': bank_transfer_request.get('currency'),
            'plan_type': bank_transfer_request.get('plan_type'),
            'reference_code': reference_code,
            'transaction_date': transaction_date,
            'transaction_ref': transaction_ref,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        # Redirect to success page
        return redirect(url_for('payments.success'))
        
    except Exception as e:
        logger.error(f"Error confirming bank transfer: {str(e)}")
        flash('An error occurred while processing your confirmation. Please try again.', 'danger')
        return redirect(url_for('payments.bank_transfer_instructions'))

@payments_bp.route('/webhook', methods=['POST'])
def webhook():
    """Handle PayPal webhook events"""
    event_type = request.headers.get('PAYPAL-TRANSMISSION-ID')
    
    if not event_type:
        logger.error("Missing PayPal transmission ID in webhook")
        return jsonify(success=False), 400
    
    try:
        # Process PayPal webhook
        payload = request.get_json()
        
        # Verify webhook signature (in production, implement proper signature validation)
        if not payload:
            return jsonify(success=False), 400
        
        # Handle different event types
        event_type = payload.get('event_type')
        
        if event_type == 'BILLING.SUBSCRIPTION.ACTIVATED':
            handle_subscription_activated(payload)
        elif event_type == 'BILLING.SUBSCRIPTION.UPDATED':
            handle_subscription_updated(payload)
        elif event_type == 'BILLING.SUBSCRIPTION.CANCELLED':
            handle_subscription_cancelled(payload)
        elif event_type == 'BILLING.SUBSCRIPTION.SUSPENDED':
            handle_subscription_suspended(payload)
        
        return jsonify(success=True)
    except Exception as e:
        logger.error(f"Error processing PayPal webhook: {str(e)}")
        return jsonify(success=False), 500

def handle_subscription_activated(payload):
    """Handle PayPal subscription activated event"""
    resource = payload.get('resource', {})
    subscription_id = resource.get('id')
    
    if not subscription_id:
        logger.error("Missing subscription ID in webhook payload")
        return
    
    # Find the subscription in the database
    # Note: In a real app, you'd need a way to associate PayPal subscription IDs with users
    user_subscription = UserSubscription.query.filter_by(paypal_subscription_id=subscription_id).first()
    
    if not user_subscription:
        logger.error(f"Subscription not found: {subscription_id}")
        return
    
    # Set subscription to active
    user_subscription.is_active = True
    db.session.commit()
    
    logger.info(f"Activated subscription {subscription_id} for user {user_subscription.user_id}")

def handle_subscription_updated(payload):
    """Handle PayPal subscription updated event"""
    resource = payload.get('resource', {})
    subscription_id = resource.get('id')
    
    if not subscription_id:
        logger.error("Missing subscription ID in webhook payload")
        return
    
    # Find the subscription in the database
    user_subscription = UserSubscription.query.filter_by(paypal_subscription_id=subscription_id).first()
    
    if not user_subscription:
        logger.error(f"Subscription not found: {subscription_id}")
        return
    
    # Update subscription status based on PayPal status
    status = resource.get('status')
    user_subscription.is_active = status == 'ACTIVE'
    
    db.session.commit()
    logger.info(f"Updated subscription {subscription_id} for user {user_subscription.user_id}")

def handle_subscription_cancelled(payload):
    """Handle PayPal subscription cancelled event"""
    resource = payload.get('resource', {})
    subscription_id = resource.get('id')
    
    if not subscription_id:
        logger.error("Missing subscription ID in webhook payload")
        return
    
    # Find the subscription in the database
    user_subscription = UserSubscription.query.filter_by(paypal_subscription_id=subscription_id).first()
    
    if not user_subscription:
        logger.error(f"Subscription not found: {subscription_id}")
        return
    
    # Mark subscription as inactive
    user_subscription.is_active = False
    user_subscription.end_date = datetime.utcnow()
    
    # Update user role to free
    user = User.query.get(user_subscription.user_id)
    if user:
        user.role = 'free'
    
    db.session.commit()
    logger.info(f"Cancelled subscription {subscription_id} for user {user_subscription.user_id}")

def handle_subscription_suspended(payload):
    """Handle PayPal subscription suspended event"""
    resource = payload.get('resource', {})
    subscription_id = resource.get('id')
    
    if not subscription_id:
        logger.error("Missing subscription ID in webhook payload")
        return
    
    # Find the subscription in the database
    user_subscription = UserSubscription.query.filter_by(paypal_subscription_id=subscription_id).first()
    
    if not user_subscription:
        logger.error(f"Subscription not found: {subscription_id}")
        return
    
    # Mark subscription as inactive but don't end it completely
    user_subscription.is_active = False
    
    db.session.commit()
    logger.info(f"Suspended subscription {subscription_id} for user {user_subscription.user_id}")

def get_domain_url():
    """Get the domain URL for PayPal success/cancel redirects"""
    # For Replit deployments
    if os.environ.get('REPLIT_DEPLOYMENT'):
        return "https://" + os.environ.get('REPLIT_DEV_DOMAIN', '')
    else:
        # For local development or other hosting, use the first domain
        # from the comma-separated REPLIT_DOMAINS environment variable
        domains = os.environ.get('REPLIT_DOMAINS', 'localhost:5000').split(',')
        return "http://" + domains[0]  # Default to HTTP protocol for local development

def init_app(app):
    """Initialize payments with Flask app"""
    app.register_blueprint(payments_bp)
    
    # Check if PayPal credentials are configured
    if not PAYPAL_CLIENT_ID or not PAYPAL_CLIENT_SECRET:
        logger.warning("PayPal credentials not configured. Payment features will be limited.")