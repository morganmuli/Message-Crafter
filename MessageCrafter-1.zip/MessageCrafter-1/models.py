from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(UserMixin, db.Model):
    """User model for authentication and profile information"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), default='free')  # 'free', 'pro', or 'admin'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    preferred_language = db.Column(db.String(10), default='en')
    custom_api_key = db.Column(db.String(100), nullable=True)
    
    # Relationships
    message_generations = db.relationship('MessageGeneration', backref='user', lazy='dynamic')
    favorites = db.relationship('FavoriteMessage', backref='user', lazy='dynamic')
    message_feedbacks = db.relationship('MessageFeedback', backref='user', lazy='dynamic')
    
    def set_password(self, password):
        """Set password hash"""
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        """Check password against stored hash"""
        return check_password_hash(self.password_hash, password)
    
    def is_pro(self):
        """Check if user has pro access"""
        return self.role in ('pro', 'admin')
    
    def is_admin(self):
        """Check if user has admin access"""
        return self.role == 'admin'
    
    def to_dict(self):
        """Convert user to dictionary for API responses"""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'preferred_language': self.preferred_language
        }

class MessageGeneration(db.Model):
    """Model for tracking message generation history"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='SET NULL'), nullable=True)
    situation = db.Column(db.Text, nullable=False)
    tone = db.Column(db.String(50), nullable=False)
    platform = db.Column(db.String(50), nullable=False)
    recipient_info = db.Column(db.Text, nullable=True)
    language = db.Column(db.String(10), default='en')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    generation_time_ms = db.Column(db.Integer, nullable=True)  # Time to generate in milliseconds
    
    # Store individual messages
    message_1 = db.Column(db.Text, nullable=True)
    message_2 = db.Column(db.Text, nullable=True)
    message_3 = db.Column(db.Text, nullable=True)
    
    # Relationships
    favorites = db.relationship('FavoriteMessage', backref='message_generation', lazy='dynamic')
    feedbacks = db.relationship('MessageFeedback', backref='message_generation', lazy='dynamic')
    
    def __repr__(self):
        return f'<MessageGeneration {self.id}: {self.platform}, {self.tone}>'
    
    def to_dict(self):
        """Convert the model instance to a dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'situation': self.situation,
            'tone': self.tone,
            'platform': self.platform,
            'recipient_info': self.recipient_info,
            'language': self.language,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'generation_time_ms': self.generation_time_ms,
            'messages': [
                self.message_1,
                self.message_2,
                self.message_3
            ]
        }

class FavoriteMessage(db.Model):
    """Model for saved favorite messages"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)
    message_generation_id = db.Column(db.Integer, db.ForeignKey('message_generation.id', ondelete='CASCADE'), nullable=False)
    message_index = db.Column(db.Integer, nullable=False)  # 0, 1, or 2 to indicate which message was favorited
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<FavoriteMessage {self.id}>'
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'message_generation_id': self.message_generation_id,
            'message_index': self.message_index,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class MessageFeedback(db.Model):
    """Model for tracking message feedback (thumbs up/down)"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='SET NULL'), nullable=True)
    message_generation_id = db.Column(db.Integer, db.ForeignKey('message_generation.id', ondelete='CASCADE'), nullable=False)
    message_index = db.Column(db.Integer, nullable=False)  # 0, 1, or 2 to indicate which message received feedback
    is_positive = db.Column(db.Boolean, nullable=False)  # True for thumbs up, False for thumbs down
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<MessageFeedback {self.id}>'

class UserSubscription(db.Model):
    """Model for tracking user subscriptions"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)
    
    # Payment method identifiers
    stripe_customer_id = db.Column(db.String(100), nullable=True)
    stripe_subscription_id = db.Column(db.String(100), nullable=True)
    paypal_subscription_id = db.Column(db.String(100), nullable=True)
    bank_transfer_reference = db.Column(db.String(100), nullable=True)
    
    payment_method = db.Column(db.String(20), default='none')  # 'stripe', 'paypal', 'bank_transfer'
    
    plan_type = db.Column(db.String(50), nullable=False)  # 'monthly', 'annual'
    is_active = db.Column(db.Boolean, default=True)
    is_pending_verification = db.Column(db.Boolean, default=False)  # For bank transfers
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=True)
    
    # For bank transfers
    transfer_transaction_id = db.Column(db.String(100), nullable=True)
    transfer_date = db.Column(db.DateTime, nullable=True)
    
    def __repr__(self):
        return f'<UserSubscription {self.id}>'
        
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'payment_method': self.payment_method,
            'plan_type': self.plan_type,
            'is_active': self.is_active,
            'is_pending_verification': self.is_pending_verification,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None
        }

class AnalyticsData(db.Model):
    """Model for tracking usage analytics"""
    id = db.Column(db.Integer, primary_key=True)
    event_type = db.Column(db.String(50), nullable=False, index=True)  # 'message_generation', 'copy', 'share', etc.
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='SET NULL'), nullable=True)
    message_generation_id = db.Column(db.Integer, db.ForeignKey('message_generation.id', ondelete='SET NULL'), nullable=True)
    platform = db.Column(db.String(50), nullable=True)
    tone = db.Column(db.String(50), nullable=True)
    language = db.Column(db.String(10), nullable=True)
    occurred_at = db.Column(db.DateTime, default=datetime.utcnow)
    additional_data = db.Column(db.JSON, nullable=True)  # For any extra event-specific data
    
    def __repr__(self):
        return f'<AnalyticsData {self.id}>'