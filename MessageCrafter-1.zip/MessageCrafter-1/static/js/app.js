document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const messageForm = document.getElementById('messageForm');
    const generateBtn = document.getElementById('generateBtn');
    const btnText = document.getElementById('btnText');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const resultsContainer = document.getElementById('resultsContainer');
    const messageContainer = document.querySelector('.message-container');
    const errorContainer = document.getElementById('errorContainer');
    const errorMessage = document.getElementById('errorMessage');

    // Form elements
    const situationInput = document.getElementById('situation');
    const toneSelect = document.getElementById('tone');
    const platformSelect = document.getElementById('platform');
    const recipientInput = document.getElementById('recipient');

    // Event Listeners
    messageForm.addEventListener('submit', handleFormSubmit);

    /**
     * Handle form submission
     * @param {Event} e - Form submission event
     */
    async function handleFormSubmit(e) {
        e.preventDefault();
        
        // Validate form
        if (!validateForm()) {
            return;
        }

        // Show loading state
        setLoadingState(true);
        
        // Clear previous results and errors
        clearResults();
        hideError();

        try {
            // Get form data
            const formData = {
                situation: situationInput.value.trim(),
                tone: toneSelect.value,
                platform: platformSelect.value,
                recipient: recipientInput.value.trim()
            };

            // Call API
            const messages = await generateMessages(formData);
            
            // Display results
            displayMessages(messages, formData.platform);
            
            // Scroll to results
            resultsContainer.scrollIntoView({ behavior: 'smooth' });
            
        } catch (error) {
            showError(error.message || 'An unexpected error occurred. Please try again.');
            console.error('Error:', error);
        } finally {
            // Reset loading state
            setLoadingState(false);
        }
    }

    /**
     * Validate form inputs
     * @returns {boolean} - Whether form is valid
     */
    function validateForm() {
        if (!situationInput.value.trim()) {
            showError('Please describe the situation for your message.');
            situationInput.focus();
            return false;
        }
        
        if (!toneSelect.value) {
            showError('Please select a tone for your message.');
            toneSelect.focus();
            return false;
        }
        
        if (!platformSelect.value) {
            showError('Please select a platform for your message.');
            platformSelect.focus();
            return false;
        }
        
        return true;
    }

    /**
     * Call the backend API to generate messages
     * @param {Object} data - Form data
     * @returns {Promise<Array>} - Array of generated messages
     */
    async function generateMessages(data) {
        const response = await fetch('/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });

        const responseData = await response.json().catch(() => ({}));
        
        // Special handling for quota exceeded errors (status 429)
        if (response.status === 429 && responseData.messages) {
            // Show the error message but still use the placeholder messages
            showError(responseData.error || "API quota exceeded. Please try again later.");
            return responseData.messages;
        }
        
        if (!response.ok) {
            throw new Error(responseData.error || `Error ${response.status}: Failed to generate messages`);
        }

        return responseData.messages;
    }

    /**
     * Display generated messages in the UI
     * @param {Array} messages - Array of message strings
     * @param {string} platform - Selected platform
     */
    function displayMessages(messages, platform) {
        if (!messages || messages.length === 0) {
            showError('No messages were generated. Please try again.');
            return;
        }

        // Clear previous messages
        messageContainer.innerHTML = '';
        
        // Get platform-specific class
        const platformClass = `platform-${platform.toLowerCase()}`;
        
        // Create message elements
        messages.forEach((message, index) => {
            const messageBox = document.createElement('div');
            messageBox.className = 'message-box shadow-sm';
            
            const platformBadge = document.createElement('div');
            platformBadge.className = `platform-badge ${platformClass}`;
            platformBadge.textContent = platform;
            
            const messageContent = document.createElement('div');
            messageContent.className = 'message-content';
            messageContent.textContent = message;
            
            const copyButton = document.createElement('button');
            copyButton.className = 'btn btn-sm btn-outline-secondary copy-btn';
            copyButton.innerHTML = '<i class="fa-regular fa-copy"></i>';
            copyButton.title = 'Copy to clipboard';
            copyButton.addEventListener('click', () => copyToClipboard(message, copyButton));
            
            messageBox.appendChild(platformBadge);
            messageBox.appendChild(messageContent);
            messageBox.appendChild(copyButton);
            
            messageContainer.appendChild(messageBox);
        });
        
        // Show results container
        resultsContainer.classList.remove('d-none');
    }

    /**
     * Copy message text to clipboard
     * @param {string} text - Text to copy
     * @param {HTMLElement} button - Button element
     */
    function copyToClipboard(text, button) {
        navigator.clipboard.writeText(text).then(() => {
            // Update button temporarily
            const originalHTML = button.innerHTML;
            button.innerHTML = '<i class="fa-solid fa-check"></i>';
            button.classList.add('btn-success');
            button.classList.remove('btn-outline-secondary');
            
            // Reset button after delay
            setTimeout(() => {
                button.innerHTML = originalHTML;
                button.classList.remove('btn-success');
                button.classList.add('btn-outline-secondary');
            }, 2000);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
        });
    }

    /**
     * Show error message
     * @param {string} message - Error message to display
     */
    function showError(message) {
        errorMessage.textContent = message;
        errorContainer.classList.remove('d-none');
        errorContainer.scrollIntoView({ behavior: 'smooth' });
    }

    /**
     * Hide error message
     */
    function hideError() {
        errorContainer.classList.add('d-none');
    }

    /**
     * Clear results
     */
    function clearResults() {
        messageContainer.innerHTML = '';
        resultsContainer.classList.add('d-none');
    }

    /**
     * Set loading state
     * @param {boolean} isLoading - Whether app is in loading state
     */
    function setLoadingState(isLoading) {
        if (isLoading) {
            btnText.textContent = 'Generating...';
            loadingSpinner.classList.remove('d-none');
            generateBtn.disabled = true;
            generateBtn.classList.add('btn-loading');
        } else {
            btnText.textContent = 'Generate Messages';
            loadingSpinner.classList.add('d-none');
            generateBtn.disabled = false;
            generateBtn.classList.remove('btn-loading');
        }
    }
});
