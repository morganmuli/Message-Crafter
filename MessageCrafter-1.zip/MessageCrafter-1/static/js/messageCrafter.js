/**
 * MessageCrafter - Main JavaScript
 */
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const messageForm = document.getElementById('messageForm');
    const situationInput = document.getElementById('situation');
    const toneSelect = document.getElementById('tone');
    const platformSelect = document.getElementById('platform');
    const recipientInput = document.getElementById('recipient');
    const languageSelect = document.getElementById('language');
    const generateBtn = document.getElementById('generateBtn');
    const btnText = document.getElementById('btnText');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const messageContainer = document.querySelector('.message-container');
    const resultsContainer = document.getElementById('resultsContainer');
    const errorContainer = document.getElementById('errorContainer');
    const errorMessage = document.getElementById('errorMessage');
    const characterCountElement = document.getElementById('characterCount');
    const messageCharacterLimits = {
        'Twitter': 280,
        'Instagram': 300,
        'WhatsApp': 500,
        'Email': 1000,
        'LinkedIn': 1000,
        'Facebook': 500,
        'TikTok': 300,
        'Snapchat': 250,
        'Discord': 500,
        'Slack': 500,
        'Telegram': 500
    };
    
    // Templates for pre-filled use cases
    const templates = {
        'cold_outreach': {
            situation: 'I am reaching out to a potential client I found on LinkedIn. I want to introduce my consulting services.',
            tone: 'Professional',
            platform: 'LinkedIn',
            recipient: 'Marketing Director at a mid-size tech company'
        },
        'job_application': {
            situation: 'I am following up after submitting my job application for a software developer position.',
            tone: 'Professional',
            platform: 'Email',
            recipient: 'HR Manager who posted the job listing'
        },
        'networking': {
            situation: 'I met this person at an industry conference last week and want to connect.',
            tone: 'Friendly',
            platform: 'LinkedIn',
            recipient: 'Industry peer who works in the same field'
        },
        'client_followup': {
            situation: 'I provided a proposal to a potential client last week and want to follow up.',
            tone: 'Professional',
            platform: 'Email',
            recipient: 'Business owner who requested the proposal'
        },
        'social_connection': {
            situation: 'I want to connect with someone I admire in my industry.',
            tone: 'Casual',
            platform: 'Instagram',
            recipient: 'Influencer in my field with 50k followers'
        }
    };
    
    // Initialize
    initApp();
    
    /**
     * Initialize the application
     */
    function initApp() {
        // Set up form submit handlers
        if (messageForm) {
            messageForm.addEventListener('submit', handleFormSubmit);
        }
        
        // Set up character counter for situation input
        if (situationInput && characterCountElement) {
            situationInput.addEventListener('input', updateCharacterCount);
            updateCharacterCount();
        }
        
        // Set up template selector if present
        const templateSelector = document.getElementById('templateSelector');
        if (templateSelector) {
            templateSelector.addEventListener('change', function() {
                const selectedTemplate = this.value;
                if (selectedTemplate && templates[selectedTemplate]) {
                    applyTemplate(templates[selectedTemplate]);
                }
            });
        }
        
        // Set up platform autosuggest if enabled
        const autoSuggestToggle = document.getElementById('autoSuggestToggle');
        if (autoSuggestToggle && situationInput) {
            autoSuggestToggle.addEventListener('change', function() {
                if (this.checked) {
                    situationInput.addEventListener('blur', suggestPlatformAndTone);
                } else {
                    situationInput.removeEventListener('blur', suggestPlatformAndTone);
                }
            });
        }
    }
    
    /**
     * Apply a pre-defined template to form inputs
     * @param {Object} template - Template data
     */
    function applyTemplate(template) {
        if (situationInput) situationInput.value = template.situation;
        if (toneSelect) selectOption(toneSelect, template.tone);
        if (platformSelect) selectOption(platformSelect, template.platform);
        if (recipientInput) recipientInput.value = template.recipient;
        
        if (characterCountElement) {
            updateCharacterCount();
        }
    }
    
    /**
     * Select an option in a select element by value or text
     * @param {HTMLSelectElement} selectElement - The select element
     * @param {string} value - Value or text of the option to select
     */
    function selectOption(selectElement, value) {
        for (let i = 0; i < selectElement.options.length; i++) {
            const option = selectElement.options[i];
            if (option.value === value || option.text === value) {
                selectElement.selectedIndex = i;
                return;
            }
        }
    }
    
    /**
     * Update character count for situation input
     */
    function updateCharacterCount() {
        if (situationInput && characterCountElement) {
            const count = situationInput.value.length;
            characterCountElement.textContent = count;
            
            // Add visual indicator if approaching limit
            if (count > 500) {
                characterCountElement.classList.add('text-warning');
            } else {
                characterCountElement.classList.remove('text-warning');
            }
        }
    }
    
    /**
     * Suggest platform and tone based on situation text
     */
    function suggestPlatformAndTone() {
        const situation = situationInput.value.toLowerCase();
        
        // Simple keyword-based suggestions
        if (toneSelect) {
            if (situation.includes('job') || situation.includes('professional') || situation.includes('business') || situation.includes('work')) {
                selectOption(toneSelect, 'Professional');
            } else if (situation.includes('friend') || situation.includes('casual') || situation.includes('chat')) {
                selectOption(toneSelect, 'Casual');
            } else if (situation.includes('bold') || situation.includes('confident') || situation.includes('direct')) {
                selectOption(toneSelect, 'Bold');
            } else if (situation.includes('warm') || situation.includes('friendly')) {
                selectOption(toneSelect, 'Friendly');
            }
        }
        
        if (platformSelect) {
            if (situation.includes('linkedin') || situation.includes('job') || situation.includes('professional') || situation.includes('work')) {
                selectOption(platformSelect, 'LinkedIn');
            } else if (situation.includes('email') || situation.includes('formal') || situation.includes('business')) {
                selectOption(platformSelect, 'Email');
            } else if (situation.includes('instagram') || situation.includes('photo') || situation.includes('picture')) {
                selectOption(platformSelect, 'Instagram');
            } else if (situation.includes('twitter') || situation.includes('tweet')) {
                selectOption(platformSelect, 'Twitter');
            } else if (situation.includes('whatsapp') || situation.includes('message') || situation.includes('text')) {
                selectOption(platformSelect, 'WhatsApp');
            } else if (situation.includes('facebook')) {
                selectOption(platformSelect, 'Facebook');
            } else if (situation.includes('tiktok') || situation.includes('video')) {
                selectOption(platformSelect, 'TikTok');
            } else if (situation.includes('discord') || situation.includes('gaming') || situation.includes('community')) {
                selectOption(platformSelect, 'Discord');
            } else if (situation.includes('slack') || situation.includes('workspace') || situation.includes('colleague')) {
                selectOption(platformSelect, 'Slack');
            }
        }
    }
    
    /**
     * Handle form submission
     * @param {Event} e - Form submission event
     */
    async function handleFormSubmit(e) {
        e.preventDefault();
        
        // Hide any previous errors
        hideError();
        
        // Clear previous results
        clearResults();
        
        // Validate form
        if (!validateForm()) {
            return;
        }
        
        // Set loading state
        setLoadingState(true);
        
        try {
            // Prepare data
            const data = {
                situation: situationInput.value,
                tone: toneSelect.value,
                platform: platformSelect.value,
                recipient: recipientInput ? recipientInput.value : '',
                language: languageSelect ? languageSelect.value : 'en'
            };
            
            // Generate messages
            const response = await generateMessages(data);
            
            // Display messages
            displayMessages(response.messages, data.platform, response.generation_id);
            
            // If processing time available, show it
            if (response.processing_time_ms) {
                const processingTime = document.getElementById('processingTime');
                if (processingTime) {
                    processingTime.textContent = `Generated in ${(response.processing_time_ms / 1000).toFixed(2)}s`;
                    processingTime.classList.remove('d-none');
                }
            }
            
        } catch (error) {
            showError(error.message || 'Failed to generate messages');
            console.error('Error:', error);
        } finally {
            setLoadingState(false);
        }
    }
    
    /**
     * Validate form inputs
     * @returns {boolean} - Whether form is valid
     */
    function validateForm() {
        if (!situationInput.value.trim()) {
            showError('Please describe the situation');
            situationInput.focus();
            return false;
        }
        
        if (!toneSelect.value) {
            showError('Please select a tone');
            toneSelect.focus();
            return false;
        }
        
        if (!platformSelect.value) {
            showError('Please select a platform');
            platformSelect.focus();
            return false;
        }
        
        return true;
    }
    
    /**
     * Call the backend API to generate messages
     * @param {Object} data - Form data
     * @returns {Promise<Object>} - Response with messages and generation ID
     */
    async function generateMessages(data) {
        const response = await fetch('/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });

        const responseData = await response.json().catch(() => ({}));
        
        // Special handling for quota exceeded errors (status 429)
        if (response.status === 429 && responseData.messages) {
            // Show the error message but still use the placeholder messages
            showError(responseData.error || "API quota exceeded. Please try again later.");
            return responseData;
        }
        
        // Special handling for rate limit due to free tier
        if (response.status === 429 && responseData.limit_reached) {
            showError(responseData.error);
            // Show upgrade prompt
            const upgradePrompt = document.getElementById('upgradePrompt');
            if (upgradePrompt) {
                upgradePrompt.classList.remove('d-none');
            }
            throw new Error(responseData.error);
        }
        
        if (!response.ok) {
            throw new Error(responseData.error || `Error ${response.status}: Failed to generate messages`);
        }

        return responseData;
    }
    
    /**
     * Display generated messages in the UI
     * @param {Array} messages - Array of message strings
     * @param {string} platform - Selected platform
     * @param {number} generationId - ID of the generated message
     */
    function displayMessages(messages, platform, generationId) {
        if (!messages || messages.length === 0) {
            showError('No messages were generated. Please try again.');
            return;
        }

        // Clear previous messages
        messageContainer.innerHTML = '';
        
        // Get platform-specific class and character limit
        const platformClass = `platform-${platform.toLowerCase()}`;
        const characterLimit = messageCharacterLimits[platform] || 500;
        
        // Create message elements
        messages.forEach((message, index) => {
            const messageBox = document.createElement('div');
            messageBox.className = 'message-box shadow-sm';
            
            const platformBadge = document.createElement('div');
            platformBadge.className = `platform-badge ${platformClass}`;
            platformBadge.textContent = platform;
            
            const messageContent = document.createElement('div');
            messageContent.className = 'message-content';
            messageContent.textContent = message;
            
            // Add character counter
            const charCount = document.createElement('div');
            charCount.className = 'message-char-count small';
            const charPercentage = (message.length / characterLimit) * 100;
            const charCountClass = charPercentage > 90 ? 'text-danger' : charPercentage > 75 ? 'text-warning' : 'text-secondary';
            charCount.innerHTML = `<span class="${charCountClass}">${message.length}</span>/${characterLimit} characters`;
            
            // Action buttons container
            const actionButtons = document.createElement('div');
            actionButtons.className = 'message-actions mt-2';
            
            // Copy button
            const copyButton = document.createElement('button');
            copyButton.className = 'btn btn-sm btn-outline-secondary me-2';
            copyButton.innerHTML = '<i class="fa-regular fa-copy me-1"></i>Copy';
            copyButton.title = 'Copy to clipboard';
            copyButton.setAttribute('data-index', index);
            copyButton.addEventListener('click', function() {
                copyToClipboard(message, this, generationId, index);
            });
            
            // Share button 
            const shareButton = document.createElement('button');
            shareButton.className = 'btn btn-sm btn-outline-secondary me-2';
            shareButton.innerHTML = '<i class="fa-solid fa-share-nodes me-1"></i>Share';
            shareButton.title = 'Share this message';
            shareButton.setAttribute('data-index', index);
            shareButton.addEventListener('click', function() {
                shareMessage(message, platform, this, generationId, index);
            });
            
            // Favorite button (if user is logged in)
            const isLoggedIn = document.body.classList.contains('user-logged-in');
            if (isLoggedIn && generationId) {
                const favoriteButton = document.createElement('button');
                favoriteButton.className = 'btn btn-sm btn-outline-secondary favorite-btn';
                favoriteButton.innerHTML = '<i class="fa-regular fa-star me-1"></i>Favorite';
                favoriteButton.title = 'Add to favorites';
                favoriteButton.setAttribute('data-index', index);
                favoriteButton.setAttribute('data-generation-id', generationId);
                favoriteButton.addEventListener('click', function() {
                    toggleFavorite(this, generationId, index);
                });
                
                actionButtons.appendChild(favoriteButton);
            }
            
            // Add buttons to container
            actionButtons.prepend(shareButton);
            actionButtons.prepend(copyButton);
            
            // Assemble message box
            messageBox.appendChild(platformBadge);
            messageBox.appendChild(messageContent);
            messageBox.appendChild(charCount);
            messageBox.appendChild(actionButtons);
            
            messageContainer.appendChild(messageBox);
        });
        
        // Show results container
        resultsContainer.classList.remove('d-none');
    }
    
    /**
     * Copy message text to clipboard
     * @param {string} text - Text to copy
     * @param {HTMLElement} button - Button element
     * @param {number} generationId - Message generation ID
     * @param {number} messageIndex - Index of the message (0, 1, or 2)
     */
    function copyToClipboard(text, button, generationId, messageIndex) {
        navigator.clipboard.writeText(text).then(() => {
            // Update button temporarily
            const originalHTML = button.innerHTML;
            button.innerHTML = '<i class="fa-solid fa-check me-1"></i>Copied!';
            button.classList.add('btn-success');
            button.classList.remove('btn-outline-secondary');
            
            // Reset button after delay
            setTimeout(() => {
                button.innerHTML = originalHTML;
                button.classList.remove('btn-success');
                button.classList.add('btn-outline-secondary');
            }, 2000);
            
            // Track action if generation ID is available
            if (generationId) {
                trackMessageAction('copy', generationId, messageIndex);
            }
        }).catch(err => {
            console.error('Failed to copy text: ', err);
        });
    }
    
    /**
     * Share a message
     * @param {string} text - Message text
     * @param {string} platform - Platform (for title)
     * @param {HTMLElement} button - Button element
     * @param {number} generationId - Message generation ID
     * @param {number} messageIndex - Index of the message (0, 1, or 2)
     */
    function shareMessage(text, platform, button, generationId, messageIndex) {
        if (navigator.share) {
            navigator.share({
                title: `MessageCrafter - ${platform} Message`,
                text: text
            }).then(() => {
                // Track share action
                if (generationId) {
                    trackMessageAction('share', generationId, messageIndex);
                }
                
                // Update button temporarily
                const originalHTML = button.innerHTML;
                button.innerHTML = '<i class="fa-solid fa-check me-1"></i>Shared!';
                button.classList.add('btn-success');
                button.classList.remove('btn-outline-secondary');
                
                // Reset button after delay
                setTimeout(() => {
                    button.innerHTML = originalHTML;
                    button.classList.remove('btn-success');
                    button.classList.add('btn-outline-secondary');
                }, 2000);
            }).catch(err => {
                console.error('Error sharing:', err);
                
                // Fallback to copy
                copyToClipboard(text, button, generationId, messageIndex);
            });
        } else {
            // Fallback for browsers that don't support sharing
            copyToClipboard(text, button, generationId, messageIndex);
        }
    }
    
    /**
     * Toggle favorite status of a message
     * @param {HTMLElement} button - Favorite button
     * @param {number} generationId - Message generation ID
     * @param {number} messageIndex - Index of the message (0, 1, or 2)
     */
    async function toggleFavorite(button, generationId, messageIndex) {
        const isActive = button.classList.contains('active');
        
        try {
            if (isActive) {
                // If already favorited, need to delete (requires favorite ID)
                const favoriteId = button.getAttribute('data-favorite-id');
                if (favoriteId) {
                    await fetch(`/favorites/${favoriteId}`, {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    });
                }
            } else {
                // Add to favorites
                const response = await fetch('/favorites', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        generation_id: generationId,
                        message_index: messageIndex
                    })
                });
                
                const data = await response.json();
                
                if (response.ok && data.favorite_id) {
                    button.setAttribute('data-favorite-id', data.favorite_id);
                }
            }
            
            // Toggle button state
            button.classList.toggle('active');
            button.classList.toggle('btn-outline-secondary');
            button.classList.toggle('btn-warning');
            
            if (button.classList.contains('active')) {
                button.innerHTML = '<i class="fa-solid fa-star me-1"></i>Favorited';
                button.title = 'Remove from favorites';
            } else {
                button.innerHTML = '<i class="fa-regular fa-star me-1"></i>Favorite';
                button.title = 'Add to favorites';
            }
            
        } catch (error) {
            console.error('Error toggling favorite:', error);
            showError('Failed to update favorites. Please try again.');
        }
    }
    
    /**
     * Track message actions (copy, share)
     * @param {string} actionType - Type of action ('copy' or 'share')
     * @param {number} generationId - Message generation ID
     * @param {number} messageIndex - Index of the message (0, 1, or 2)
     */
    async function trackMessageAction(actionType, generationId, messageIndex) {
        try {
            await fetch('/message-action', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action_type: actionType,
                    generation_id: generationId,
                    message_index: messageIndex
                })
            });
        } catch (error) {
            console.error(`Error tracking ${actionType} action:`, error);
            // Non-critical, continue silently
        }
    }
    
    /**
     * Show error message
     * @param {string} message - Error message to display
     */
    function showError(message) {
        errorMessage.textContent = message;
        errorContainer.classList.remove('d-none');
        errorContainer.scrollIntoView({ behavior: 'smooth' });
    }
    
    /**
     * Hide error message
     */
    function hideError() {
        errorContainer.classList.add('d-none');
        
        // Also hide upgrade prompt if shown
        const upgradePrompt = document.getElementById('upgradePrompt');
        if (upgradePrompt) {
            upgradePrompt.classList.add('d-none');
        }
    }
    
    /**
     * Clear results
     */
    function clearResults() {
        messageContainer.innerHTML = '';
        resultsContainer.classList.add('d-none');
        
        // Hide processing time if shown
        const processingTime = document.getElementById('processingTime');
        if (processingTime) {
            processingTime.classList.add('d-none');
        }
    }
    
    /**
     * Set loading state
     * @param {boolean} isLoading - Whether app is in loading state
     */
    function setLoadingState(isLoading) {
        if (isLoading) {
            btnText.textContent = 'Generating...';
            loadingSpinner.classList.remove('d-none');
            generateBtn.disabled = true;
            generateBtn.classList.add('btn-loading');
        } else {
            btnText.textContent = 'Generate Messages';
            loadingSpinner.classList.add('d-none');
            generateBtn.disabled = false;
            generateBtn.classList.remove('btn-loading');
        }
    }
});